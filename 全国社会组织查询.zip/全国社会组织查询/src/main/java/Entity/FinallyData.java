package Entity;

public class FinallyData {
}
