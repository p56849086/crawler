package Entity;

import lombok.Data;

@Data
public class 年度工作报告 {
    private String 序号;
    private String 年检报告书名称;
    private String 发布时间;
    private String url;
}
