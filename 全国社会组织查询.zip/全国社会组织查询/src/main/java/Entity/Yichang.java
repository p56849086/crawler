package Entity;

import lombok.Data;

@Data
public class Yichang {
    private String id;
    private String lierushijian;
    private String lierushiyou;
    private String yichushijian;
    private String yichushiyou;

}
