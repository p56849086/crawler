package Entity.信息公示实体类;

import lombok.Data;

@Data
public class 中央财政支持项目 {
    private String 序号;
    private String 年度;
    private String 项目编号;
    private String 项目名称;
    private String 立项资金_万元;
}
