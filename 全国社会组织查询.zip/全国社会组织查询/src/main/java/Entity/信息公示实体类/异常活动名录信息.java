package Entity.信息公示实体类;

import lombok.Data;

@Data
public class 异常活动名录信息 {
    private String 序号;
    private String 列入时间;
    private String 列入事由;
    private String 移出时间;
    private String 移出事由;
}
