package Entity.信息公示实体类;

import lombok.Data;

@Data
public class 年检结果 {
    private String 序号;
    private String 年度;
    private String 年检结果;
}
