package Entity.信息公示实体类;

import lombok.Data;

@Data
public class 表彰信息 {
    private String 序号;
    private String 荣誉名称;
    private String 日期;
}
