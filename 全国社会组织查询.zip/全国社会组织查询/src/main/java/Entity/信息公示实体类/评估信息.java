package Entity.信息公示实体类;

import lombok.Data;

@Data
public class 评估信息 {
    private String 序号;
    private String 评估等级;
    private String 等级有效期;
}
