package Entity;

import lombok.Data;

@Data
public class MinZheng {
    //private String id;
    private String organizationName;
    private String unifiedCode;
    private String organizationType;
    private String organizationBoss;
    private String organizationTime;
    private String organizationStatue;
    private String orgId;
}
